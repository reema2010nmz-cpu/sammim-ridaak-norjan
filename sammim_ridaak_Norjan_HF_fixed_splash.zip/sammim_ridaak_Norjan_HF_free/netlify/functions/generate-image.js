const { Client } = require('@gradio/client');

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  };

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const prompt = String(body.prompt || '').trim();
    if (!prompt) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'لم تصل مواصفات التصميم.' }) };
    }

    // Public Hugging Face ZeroGPU Space. No API key is placed in the browser.
    const app = await Client.connect('mrfakename/Z-Image-Turbo');
    const result = await app.predict('/generate_image', {
      prompt,
      height: 1024,
      width: 1024,
      num_inference_steps: 9,
      seed: Math.floor(Math.random() * 4294967295),
      randomize_seed: true
    });

    const first = result?.data?.[0];
    const imageUrl = typeof first === 'string'
      ? first
      : (first?.url || first?.path || first?.image || null);

    if (!imageUrl) {
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({ error: 'لم تصل الصورة من Hugging Face.' })
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ image: imageUrl })
    };
  } catch (error) {
    const message = error?.message || String(error) || 'حدث خطأ أثناء الاتصال بخدمة توليد الصور.';
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: message })
    };
  }
};
