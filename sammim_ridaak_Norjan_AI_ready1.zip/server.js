
const express = require("express");
const { Client } = require("@gradio/client");

const app = express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(__dirname + "/public"));

const PORT = process.env.PORT || 3000;
const HF_SPACE = "mrfakename/Z-Image-Turbo";

function esc(s=""){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

function fallbackBoard(spec){
  const color = spec.colorHex || "#8b1e3f";
  const garment = esc(spec.garment || "قطعة أزياء");
  const details = [
    ["الستايل",spec.style],["القصة",spec.fit],["الرقبة",spec.neckline],
    ["الأكمام",spec.sleeves],["الطول",spec.length],["القماش",spec.fabric],
    ["اللون",spec.color],["التفاصيل",spec.details]
  ].filter(x=>x[1]);

  const chips = details.map((d,i)=>{
    const y=155+i*82;
    const side=i%2===0;
    const x=side?55:665;
    const lineX=side?300:665;
    const textX=side?55:690;
    return `<g>
      <line x1="${lineX}" y1="${y+24}" x2="${side?445:555}" y2="${y+24}" stroke="#9b7a4a" stroke-width="2"/>
      <circle cx="${lineX}" cy="${y+24}" r="5" fill="#9b7a4a"/>
      <text x="${textX}" y="${y}" font-size="18" font-weight="700" fill="#5a4630">${esc(d[0])}</text>
      <text x="${textX}" y="${y+30}" font-size="16" fill="#7b6a57">${esc(d[1])}</text>
    </g>`;
  }).join("");

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
  <svg xmlns="http://www.w3.org/2000/svg" width="900" height="1200" viewBox="0 0 900 1200">
    <rect width="900" height="1200" fill="#f7f1e7"/>
    <rect x="24" y="24" width="852" height="1152" rx="28" fill="none" stroke="#d4bd9a" stroke-width="2"/>
    <text x="450" y="72" text-anchor="middle" font-size="28" font-weight="700" fill="#4d3a27">صمّم رداءك</text>
    <text x="450" y="108" text-anchor="middle" font-size="18" fill="#8b755b">${garment}</text>
    ${chips}
    <g transform="translate(290,250)">
      <path d="M160 0 C125 22 116 58 116 95 L85 155 L42 245 L70 265 L108 205 L98 520 L78 800 L245 800 L225 520 L215 205 L253 265 L281 245 L238 155 L207 95 C207 58 195 22 160 0Z"
            fill="${color}" stroke="#3f2b24" stroke-width="5"/>
      <path d="M116 95 Q160 130 207 95" fill="none" stroke="#d6b16e" stroke-width="8"/>
      <path d="M108 205 Q160 245 215 205" fill="none" stroke="#d6b16e" stroke-width="5"/>
      <path d="M100 520 Q160 550 225 520" fill="none" stroke="#d6b16e" stroke-width="4"/>
      <circle cx="160" cy="185" r="9" fill="#d6b16e"/>
      <circle cx="160" cy="225" r="9" fill="#d6b16e"/>
      <circle cx="160" cy="265" r="9" fill="#d6b16e"/>
      <path d="M120 350 Q160 390 200 350" fill="none" stroke="#ffffff" opacity=".25" stroke-width="4"/>
      <path d="M120 430 Q160 470 200 430" fill="none" stroke="#ffffff" opacity=".18" stroke-width="4"/>
    </g>
    <text x="450" y="1100" text-anchor="middle" font-size="16" fill="#9b7a4a">Norjan © 2026 — جميع الحقوق محفوظة</text>
  </svg>`)}`
}

async function hfGenerate(prompt){
  const client = await Client.connect(HF_SPACE);
  const result = await client.predict("/generate_image", {
    prompt,
    height: 1024,
    width: 768,
    num_inference_steps: 9,
    seed: Math.floor(Math.random()*4294967295),
    randomize_seed: true
  });
  const first = result?.data?.[0];
  return typeof first === "string" ? first : (first?.url || first?.path || first?.image || null);
}

app.post("/api/generate", async (req,res)=>{
  const s = req.body?.spec || {};
  const prompt = [
    "single fashion garment design board, one garment only, centered full front view",
    "clean light cream studio background, elegant fashion illustration/product design sheet",
    "realistic detailed garment, no model, no person, no extra garments, no text in the image",
    s.garment && `garment: ${s.garment}`,
    s.style && `style: ${s.style}`,
    s.pattern && `pattern: ${s.pattern}`,
    s.fit && `fit: ${s.fit}`,
    s.neckline && `neckline/collar: ${s.neckline}`,
    s.sleeves && `sleeves: ${s.sleeves}`,
    s.sleeveLength && `sleeve length: ${s.sleeveLength}`,
    s.length && `garment length: ${s.length}`,
    s.waist && `waist: ${s.waist}`,
    s.leg && `cut: ${s.leg}`,
    s.fabric && `fabric: ${s.fabric}`,
    s.color && `color: ${s.color}`,
    s.details && `details: ${s.details}`,
    "preserve every specified feature exactly; fashion technical design board aesthetic"
  ].filter(Boolean).join(", ");

  try{
    let image = null;
    for(let attempt=0; attempt<2 && !image; attempt++){
      try{
        image = await Promise.race([
          hfGenerate(prompt),
          new Promise((_,rej)=>setTimeout(()=>rej(new Error("generation timeout")), 45000))
        ]);
      }catch(e){}
    }
    if(image) return res.json({image, mode:"ai"});
    return res.json({image:fallbackBoard(s), mode:"instant-fallback"});
  }catch(e){
    return res.json({image:fallbackBoard(s), mode:"instant-fallback"});
  }
});

app.get("*",(req,res)=>res.sendFile(__dirname+"/public/index.html"));
app.listen(PORT,()=>console.log("صمّم رداءك يعمل على المنفذ "+PORT));
